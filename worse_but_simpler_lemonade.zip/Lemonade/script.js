// Create a new Phaser game instance
const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    parent: 'game-container', // Add a container element with the id 'game-container' in your HTML
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

const game = new Phaser.Game(config);

// Set the person1 size percentage
const person1_size_percent = 300; // 50% of the original size

function preload() {
    // Load the background and customer images
    this.load.image('background', 'background.png');
    this.load.image('customer', 'person1.png');
}

function create() {
    // Set up the initial state of the game here
    const backgroundImage = this.add.image(0, 0, 'background').setOrigin(0);

    // Calculate the new dimensions for the game window based on the resized image
    const newWidth = backgroundImage.width * 0.75;
    const newHeight = backgroundImage.height * 0.75;

    // Resize the background image to be 25% smaller
    backgroundImage.setScale(0.75);

    // Resize the game window to match the new dimensions
    game.scale.resize(newWidth, newHeight);
    game.canvas.style.width = newWidth + 'px';
    game.canvas.style.height = newHeight + 'px';
    game.canvas.style.margin = 'auto';

    let clickedOnce = false;

    // Add input event listener
    this.input.on('pointerdown', () => {
        if (!clickedOnce) {
            // Add the customer image to the center of the screen and scale it based on person1_size_percent
            const customerImage = this.add.image(newWidth / 2, (newHeight / 2) + 47, 'customer');
            const scale = person1_size_percent / 100;
            customerImage.setScale(scale);
            clickedOnce = true;

            // Generate and display an order when the customer is clicked
            generateOrder();
            displayOrder(this); // Pass the scene reference to displayOrder
        }
    });
}

function update() {
    // Update the game logic in this function (e.g., movement, collision detection)
}
