// Define the drinks data
let drinks = [
    { name: "Lemonade", percentage: 0 },
    { name: "Chocolate Milk", percentage: 0 },
    { name: "Tea", percentage: 0 },
    { name: "Coffee", percentage: 0 },
];

// Function to generate a random order
function generateOrder() {
    let firstDrinkIndex = Phaser.Math.Between(0, 3);
    let secondDrinkIndex = Phaser.Math.Between(0, 3);

    while (secondDrinkIndex === firstDrinkIndex) {
        secondDrinkIndex = Phaser.Math.Between(0, 3);
    }

    let firstDrinkPercentage = Phaser.Math.Between(1, 2) * 50;

    if (firstDrinkPercentage === 100) {
        drinks[firstDrinkIndex].percentage = 100;
    } else {
        drinks[firstDrinkIndex].percentage = firstDrinkPercentage;
        drinks[secondDrinkIndex].percentage = 100 - firstDrinkPercentage;
    }
}

// Function to display the order
function displayOrder(scene) {
    let orderText = scene.add.text(50, 50, "Order:", { font: "24px Arial", fill: "#ffffff" });

    for (let drink of drinks) {
        orderText.setText(orderText.text + "\n" + drink.percentage + "% " + drink.name);
    }

    if (drinks.some(drink => drink.percentage === 25)) {
        // If a drink has 25% percentage, generate another order
        generateOrder();
    }
}
